import Topbar from "../_components/Topbar";
import Messages from "./ui";

export default function MessagesPage() {
  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <Messages />
    </>
  );
}
