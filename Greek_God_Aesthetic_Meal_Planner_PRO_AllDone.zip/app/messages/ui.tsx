"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Msg = { id:string; created_at:string; sender_role:"client"|"admin"; body:string };

export default function Messages() {
  const supabase = createClient();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [body, setBody] = useState("");
  const [status, setStatus] = useState<string|null>(null);

  async function load() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) { setStatus("Please log in."); return; }

    const { data, error } = await supabase
      .from("messages")
      .select("id, created_at, sender_role, body")
      .eq("user_id", userData.user.id)
      .order("created_at", { ascending: true });

    if (error) setStatus(error.message);
    setMsgs((data as any) ?? []);
  }

  useEffect(() => { load(); }, []);

  async function send() {
    setStatus(null);
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) { setStatus("Please log in."); return; }
    if (!body.trim()) return;

    const { error } = await supabase.from("messages").insert({
      user_id: user.id,
      sender_id: user.id,
      sender_role: "client",
      body: body.trim(),
    });
    if (error) setStatus(error.message);
    else {
      setBody("");
      await load();
    }
  }

  return (
    <div className="grid">
      <div className="card">
        <h2 style={{marginTop:0}}>Message your coach</h2>
        <p className="small">Ask questions, request tweaks, or share feedback. (Admin can reply.)</p>
        <div className="row">
          <label>Message</label>
          <textarea rows={4} value={body} onChange={(e)=>setBody(e.target.value)} placeholder="Type here..." />
        </div>
        <button className="btn" onClick={send}>Send</button>
        {status && <div className="small" style={{marginTop:10}}>{status}</div>}
      </div>

      <div className="card">
        <h2 style={{marginTop:0}}>Thread</h2>
        {!msgs.length ? <p className="small">No messages yet.</p> : (
          <div style={{display:"grid", gap:10}}>
            {msgs.map(m=>(
              <div key={m.id} className="card" style={{padding:12, background:"#0f131b"}}>
                <div className="small">
                  <b>{m.sender_role === "admin" ? "Coach" : "You"}</b> • {new Date(m.created_at).toLocaleString()}
                </div>
                <div style={{marginTop:6}}>{m.body}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
