import { createClient } from "@/lib/supabase/server";
import Topbar from "../../../_components/Topbar";

function Table({ rows }: { rows: any[] }) {
  return (
    <table>
      <thead><tr><th>Meal</th><th>Food ideas</th><th>Portions</th></tr></thead>
      <tbody>
        {rows.map((r,idx)=>(
          <tr key={idx}><td><b>{r.meal}</b></td><td>{r.foods}</td><td>{r.portions}</td></tr>
        ))}
      </tbody>
    </table>
  );
}

export default async function PrintPlan({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: plan } = await supabase.from("meal_plans").select("created_at, plan_json, calories, protein_g, carbs_g, fats_g").eq("id", params.id).single();
  const payload:any = plan?.plan_json;
  const kind = payload?.kind ?? "day";

  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <div className="card">
        <div className="no-print" style={{display:"flex", justifyContent:"flex-end", gap:10}}>
          <button className="btn" onClick={() => window.print()}>Print / Save as PDF</button>
        </div>

        <h2 style={{marginTop:0}}>Greek God Aesthetic Meal Plan</h2>
        <div className="small">Saved: {plan ? new Date(plan.created_at).toLocaleString() : "-"}</div>

        {plan && (
          <div className="kpi">
            <div className="box"><div className="v">{plan.calories}</div><div className="k">Calories/day</div></div>
            <div className="box"><div className="v">{plan.protein_g} g</div><div className="k">Protein/day</div></div>
            <div className="box"><div className="v">{plan.carbs_g} g</div><div className="k">Carbs/day</div></div>
            <div className="box"><div className="v">{plan.fats_g} g</div><div className="k">Fats/day</div></div>
          </div>
        )}

        <div className="hr" />

        {kind === "week" ? (
          <>
            {payload.week?.map((d:any, idx:number)=>(
              <div key={idx} style={{marginBottom:16}}>
                <div style={{fontWeight:900}}>Day {idx+1}</div>
                <Table rows={d.rows} />
              </div>
            ))}

            <div className="hr" />
            <h3 style={{margin:"0 0 6px 0"}}>Grocery list (approx)</h3>
            <table>
              <thead><tr><th>Item</th><th>Times used</th><th>Estimated total</th></tr></thead>
              <tbody>
                {(payload.grocery ?? []).slice(0,60).map((g:any, idx:number)=>(
                  <tr key={idx}><td>{g.item}</td><td>{g.count}</td><td>{g.quantity} {g.unit}</td></tr>
                ))}
              </tbody>
            </table>
          </>
        ) : (
          <Table rows={payload.rows ?? []} />
        )}

        <p className="small" style={{marginTop:12}}>Tip: in the print dialog choose “Save as PDF”.</p>
      </div>
    </>
  );
}
