import Topbar from "../../_components/Topbar";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function PlanDetail({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: plan, error } = await supabase
    .from("meal_plans")
    .select("created_at, plan_json, calories, protein_g, carbs_g, fats_g")
    .eq("id", params.id)
    .single();

  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <div className="card">
        <div className="no-print" style={{display:"flex", gap:10, justifyContent:"flex-end"}}>
          <Link className="btn secondary" href={`/plans/${params.id}/print`}>Print / PDF</Link>
        </div>

        <h2 style={{marginTop:0}}>Plan</h2>
        {error && <div className="small">{error.message}</div>}
        {!plan ? null : (
          <>
            <div className="small">Saved: {new Date(plan.created_at).toLocaleString()}</div>

            <div className="kpi">
              <div className="box"><div className="v">{plan.calories}</div><div className="k">Calories/day</div></div>
              <div className="box"><div className="v">{plan.protein_g} g</div><div className="k">Protein/day</div></div>
              <div className="box"><div className="v">{plan.carbs_g} g</div><div className="k">Carbs/day</div></div>
              <div className="box"><div className="v">{plan.fats_g} g</div><div className="k">Fats/day</div></div>
            </div>

            <div className="hr" />
            <pre style={{whiteSpace:"pre-wrap", margin:0, fontSize:12, color:"var(--muted)"}}>
{JSON.stringify(plan.plan_json, null, 2)}
            </pre>
          </>
        )}
      </div>
    </>
  );
}
