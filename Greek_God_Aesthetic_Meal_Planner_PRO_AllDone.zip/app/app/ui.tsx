"use client";

import { useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import {
  ALLERGY_OPTIONS,
  PREFERRED_PROTEIN_OPTIONS,
  AVOID_FOOD_OPTIONS,
  generateDayPlan,
  generateWeekPlan,
  groceryToCSV,
  type Inputs,
} from "@/lib/mealEngine";

const GOALS = [
  { value: "cut", label: "Lose Fat" },
  { value: "maintain", label: "Maintain" },
  { value: "bulk", label: "Build Muscle" },
] as const;

const ACTIVITY = [
  { value: 1.2, label: "Sedentary (little exercise)" },
  { value: 1.375, label: "Light (1–3 days/wk)" },
  { value: 1.55, label: "Moderate (3–5 days/wk)" },
  { value: 1.725, label: "Active (6–7 days/wk)" },
  { value: 1.9, label: "Very Active (twice/day or physical job)" },
] as const;

const DIET = [
  { value: "standard", label: "Standard" },
  { value: "high_protein", label: "High-Protein" },
  { value: "low_carb", label: "Low-Carb" },
  { value: "vegetarian", label: "Vegetarian" },
  { value: "vegan", label: "Vegan" },
] as const;

export default function Planner() {
  const supabase = createClient();

  const [inputs, setInputs] = useState<Inputs>({
    goal: "cut",
    activity: 1.55,
    mealsPerDay: 4,
    heightFt: 6,
    heightIn: 0,
    weightLb: 180,
    sex: "male",
    age: 25,
    dietType: "standard",
    allergies: ["None","None","None"],
    preferredProtein: "No preference",
    avoidFood: "None",
  });

  const [mode, setMode] = useState<"day"|"week">("week");
  const computed = useMemo(() => (mode==="day" ? { kind:"day" as const, ...generateDayPlan(inputs) } : { kind:"week" as const, ...generateWeekPlan(inputs) }), [inputs, mode]);
  const [status, setStatus] = useState<string|null>(null);

  function set<K extends keyof Inputs>(k: K, v: Inputs[K]) { setInputs((p)=>({ ...p, [k]: v })); }
  function setAllergy(idx:number, v:string){
    const next=[...inputs.allergies]; next[idx]=v; setInputs(p=>({ ...p, allergies: next }));
  }

  function downloadCSV(){
    if(computed.kind!=="week") return;
    const csv = groceryToCSV(computed.grocery);
    const blob = new Blob([csv], { type:"text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href=url;
    a.download="grocery-list.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  async function savePlan() {
    setStatus(null);
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) { setStatus("Please log in first."); return; }

    const metricsInsert = await supabase
      .from("client_metrics")
      .insert({
        user_id: user.id,
        height_ft: inputs.heightFt,
        height_in: inputs.heightIn,
        weight_lb: inputs.weightLb,
        sex: inputs.sex ?? null,
        age: inputs.age ?? null,
        activity: inputs.activity,
        goal: inputs.goal,
        meals_per_day: inputs.mealsPerDay,
        diet_type: inputs.dietType,
        allergies: inputs.allergies.filter(a=>a!=="None"),
        preferred_protein: inputs.preferredProtein,
        avoid_food: inputs.avoidFood,
      })
      .select("id")
      .single();

    if (metricsInsert.error) { setStatus(metricsInsert.error.message); return; }

    const targets = computed.targets;

    const payload:any = computed.kind==="day"
      ? { kind:"day", inputs, targets, rows: computed.rows, restrictions: computed.meta.restrictions }
      : { kind:"week", inputs, targets, week: computed.week, grocery: computed.grocery, restrictions: computed.meta.restrictions };

    const planInsert = await supabase.from("meal_plans").insert({
      user_id: user.id,
      metrics_id: metricsInsert.data.id,
      calories: targets.calories,
      protein_g: targets.protein_g,
      carbs_g: targets.carbs_g,
      fats_g: targets.fats_g,
      plan_json: payload,
    });

    if(planInsert.error) setStatus(planInsert.error.message);
    else setStatus("Saved! View it in Plans.");
  }

  return (
    <div className="grid">
      <div className="card">
        <h2 style={{marginTop:0}}>Your Inputs</h2>

        <div className="row">
          <label>Plan type</label>
          <select value={mode} onChange={(e)=>setMode(e.target.value as any)}>
            <option value="week">7-day plan + grocery list</option>
            <option value="day">1-day plan</option>
          </select>
        </div>

        <div className="row">
          <label>Goal</label>
          <select value={inputs.goal} onChange={(e)=>set("goal", e.target.value as any)}>
            {GOALS.map(g => <option key={g.value} value={g.value}>{g.label}</option>)}
          </select>
        </div>

        <div className="row">
          <label>Activity</label>
          <select value={inputs.activity} onChange={(e)=>set("activity", Number(e.target.value))}>
            {ACTIVITY.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
          </select>
        </div>

        <div className="row">
          <label>Meals per day</label>
          <select value={inputs.mealsPerDay} onChange={(e)=>set("mealsPerDay", Number(e.target.value) as any)}>
            {[3,4,5].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>

        <div className="row" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div className="row" style={{margin:0}}>
            <label>Height (ft)</label>
            <select value={inputs.heightFt} onChange={(e)=>set("heightFt", Number(e.target.value))}>
              {[4,5,6,7].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div className="row" style={{margin:0}}>
            <label>Height (in)</label>
            <select value={inputs.heightIn} onChange={(e)=>set("heightIn", Number(e.target.value))}>
              {Array.from({length:12},(_,i)=>i).map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>

        <div className="row">
          <label>Weight (lb)</label>
          <input type="number" min={60} max={500} value={inputs.weightLb} onChange={(e)=>set("weightLb", Number(e.target.value))} />
        </div>

        <div className="row" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div className="row" style={{margin:0}}>
            <label>Sex (optional)</label>
            <select value={inputs.sex ?? "male"} onChange={(e)=>set("sex", e.target.value as any)}>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
          <div className="row" style={{margin:0}}>
            <label>Age (optional)</label>
            <input type="number" min={14} max={90} value={inputs.age ?? 25} onChange={(e)=>set("age", Number(e.target.value))} />
          </div>
        </div>

        <div className="hr" />

        <div className="row">
          <label>Diet Type</label>
          <select value={inputs.dietType} onChange={(e)=>set("dietType", e.target.value as any)}>
            {DIET.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
          </select>
        </div>

        <div className="row">
          <label>Allergies / Restrictions (choose up to 3)</label>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
            {[0,1,2].map(idx=>(
              <select key={idx} value={inputs.allergies[idx]} onChange={(e)=>setAllergy(idx, e.target.value)}>
                {ALLERGY_OPTIONS.map(a=><option key={a} value={a}>{a}</option>)}
              </select>
            ))}
          </div>
          <div className="small">Pick “None” if not needed.</div>
        </div>

        <div className="row">
          <label>Preferred protein</label>
          <select value={inputs.preferredProtein} onChange={(e)=>set("preferredProtein", e.target.value)}>
            {PREFERRED_PROTEIN_OPTIONS.map(p=><option key={p} value={p}>{p}</option>)}
          </select>
        </div>

        <div className="row">
          <label>Food to avoid</label>
          <select value={inputs.avoidFood} onChange={(e)=>set("avoidFood", e.target.value)}>
            {AVOID_FOOD_OPTIONS.map(a=><option key={a} value={a}>{a}</option>)}
          </select>
        </div>

        <button className="btn" onClick={savePlan}>Save this plan</button>
        {status && <div className="small" style={{marginTop:10}}>{status}</div>}
      </div>

      <div className="card">
        <h2 style={{marginTop:0}}>Your Plan</h2>

        <div>
          <span className="badge">{inputs.goal==="cut"?"Lose Fat":inputs.goal==="bulk"?"Build Muscle":"Maintain"}</span>
          <span className="badge">{inputs.dietType.replaceAll("_"," ").replace(/\b\w/g,c=>c.toUpperCase())}</span>
          <span className="badge">{computed.meta.restrictions.length?`Restrictions: ${computed.meta.restrictions.join(", ")}`:"No restrictions"}</span>
        </div>

        <div className="kpi">
          <div className="box"><div className="v">{computed.targets.calories}</div><div className="k">Calories/day</div></div>
          <div className="box"><div className="v">{computed.targets.protein_g} g</div><div className="k">Protein/day</div></div>
          <div className="box"><div className="v">{computed.targets.carbs_g} g</div><div className="k">Carbs/day</div></div>
          <div className="box"><div className="v">{computed.targets.fats_g} g</div><div className="k">Fats/day</div></div>
        </div>

        {computed.kind==="day" ? (
          <table>
            <thead><tr><th>Meal</th><th>Food ideas</th><th>Portions</th></tr></thead>
            <tbody>
              {computed.rows.map((r,idx)=>(
                <tr key={idx}><td><b>{r.meal}</b></td><td>{r.foods}</td><td>{r.portions}</td></tr>
              ))}
            </tbody>
          </table>
        ) : (
          <>
            <div className="no-print" style={{display:"flex", gap:10, marginTop:10, flexWrap:"wrap"}}>
              <button className="btn secondary" onClick={downloadCSV}>Download grocery list (CSV)</button>
            </div>

            <div className="hr" />

            {computed.week.map((d,di)=>(
              <div key={di} style={{marginBottom:14}}>
                <div style={{fontWeight:900}}>Day {di+1}</div>
                <table>
                  <thead><tr><th>Meal</th><th>Food ideas</th><th>Portions</th></tr></thead>
                  <tbody>
                    {d.rows.map((r,idx)=>(
                      <tr key={idx}><td><b>{r.meal}</b></td><td>{r.foods}</td><td>{r.portions}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}

            <div className="hr" />
            <h3 style={{margin:"0 0 6px 0"}}>Grocery list (approx)</h3>
            <p className="small" style={{marginTop:0}}>Counts are “times used” to help you shop. Download CSV for a clean list.</p>
            <table>
              <thead><tr><th>Item</th><th>Times used</th><th>Estimated total</th></tr></thead>
              <tbody>
                {computed.grocery.slice(0,40).map((g,idx)=>(
                  <tr key={idx}><td>{g.item}</td><td>{g.count}</td><td>{g.quantity} {g.unit}</td></tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        <p className="small" style={{marginTop:10}}>
          PDF: save the plan, then open it in Plans and use <b>Print / PDF</b>.
        </p>
      </div>
    </div>
  );
}
