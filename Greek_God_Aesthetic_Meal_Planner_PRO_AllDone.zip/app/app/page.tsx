import Topbar from "../_components/Topbar";
import Planner from "./ui";
export default function AppPage(){
  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <Planner />
    </>
  );
}
