import Topbar from "../_components/Topbar";
import LoginForm from "./ui";
export default function LoginPage(){
  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <div className="card">
        <h2 style={{marginTop:0}}>Login</h2>
        <p className="small">Use Google login (recommended) or email magic link.</p>
        <LoginForm />
      </div>
    </>
  );
}
