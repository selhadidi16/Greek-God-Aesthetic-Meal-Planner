"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginForm(){
  const supabase = createClient();
  const [email,setEmail]=useState("");
  const [msg,setMsg]=useState<string|null>(null);

  async function signInWithGoogle(){
    setMsg(null);
    const { error } = await supabase.auth.signInWithOAuth({
      provider:"google",
      options:{ redirectTo: `${location.origin}/auth/callback` }
    });
    if(error) setMsg(error.message);
  }

  async function signInWithEmail(e:React.FormEvent){
    e.preventDefault();
    setMsg(null);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options:{ emailRedirectTo: `${location.origin}/auth/callback` }
    });
    if(error) setMsg(error.message);
    else setMsg("Check your email for a magic link.");
  }

  return (
    <div style={{display:"grid",gap:12}}>
      <button className="btn" onClick={signInWithGoogle}>Continue with Google</button>
      <div className="hr" />
      <form onSubmit={signInWithEmail} style={{display:"grid",gap:10}}>
        <div className="row">
          <label>Email</label>
          <input type="email" required value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        <button className="btn secondary" type="submit">Send magic link</button>
      </form>
      {msg && <div className="small">{msg}</div>}
    </div>
  );
}
