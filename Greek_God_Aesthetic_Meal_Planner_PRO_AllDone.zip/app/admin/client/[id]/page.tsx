import Topbar from "../../../_components/Topbar";
import { createClient } from "@/lib/supabase/server";
import AdminClient from "./ui";

export default async function AdminClientPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  const role = user
    ? (await supabase.from("profiles").select("role").eq("id", user.id).single()).data?.role
    : null;

  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <AdminClient clientId={params.id} allowed={role==="admin"} />
    </>
  );
}
