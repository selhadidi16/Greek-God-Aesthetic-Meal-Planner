"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { applyMacroOverride, generateWeekPlan } from "@/lib/mealEngine";

export default function AdminClient({ clientId, allowed }: { clientId: string; allowed: boolean }) {
  const supabase = createClient();
  const [client, setClient] = useState<any>(null);
  const [latestMetrics, setLatestMetrics] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [checkins, setCheckins] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [reply, setReply] = useState("");
  const [note, setNote] = useState("");
  const [status, setStatus] = useState<string|null>(null);

  const [override, setOverride] = useState({ calories: "", protein_g: "", carbs_g: "", fats_g: "" });

  async function load(){
    const p = await supabase.from("profiles").select("id, full_name, created_at").eq("id", clientId).single();
    setClient(p.data);

    const m = await supabase.from("client_metrics").select("*").eq("user_id", clientId).order("created_at", {ascending:false}).limit(1).maybeSingle();
    setLatestMetrics(m.data);

    const pl = await supabase.from("meal_plans").select("id, created_at, calories, protein_g, carbs_g, fats_g").eq("user_id", clientId).order("created_at",{ascending:false}).limit(25);
    setPlans(pl.data ?? []);

    const ch = await supabase.from("checkins").select("checkin_date, weight_lb, notes, photo_urls, created_at").eq("user_id", clientId).order("created_at",{ascending:false}).limit(25);
    setCheckins(ch.data ?? []);

    const ms = await supabase.from("messages").select("id, created_at, sender_role, body").eq("user_id", clientId).order("created_at", {ascending:true});
    setMessages(ms.data ?? []);
  }

  useEffect(()=>{ if(allowed) load(); },[allowed]);

  async function addNote(){
    setStatus(null);
    if(!note.trim()) return;
    const { data: userData } = await supabase.auth.getUser();
    const admin = userData.user;
    if(!admin){ setStatus("Please log in."); return; }

    const { error } = await supabase.from("trainer_notes").insert({ client_id: clientId, admin_id: admin.id, note: note.trim() });
    if(error) setStatus(error.message);
    else { setStatus("Note saved."); setNote(""); }
  }


async function sendReply(){
  setStatus(null);
  const { data: userData } = await supabase.auth.getUser();
  const admin = userData.user;
  if(!admin){ setStatus("Please log in."); return; }
  if(!reply.trim()) return;

  const { error } = await supabase.from("messages").insert({
    user_id: clientId,
    sender_id: admin.id,
    sender_role: "admin",
    body: reply.trim(),
  });
  if(error) setStatus(error.message);
  else { setReply(""); await load(); }
}

  async function regenerateWithOverride(){
    setStatus(null);
    if(!latestMetrics){ setStatus("No metrics found for this client."); return; }

    const inputs:any = {
      goal: latestMetrics.goal,
      activity: Number(latestMetrics.activity),
      mealsPerDay: Number(latestMetrics.meals_per_day),
      heightFt: Number(latestMetrics.height_ft),
      heightIn: Number(latestMetrics.height_in),
      weightLb: Number(latestMetrics.weight_lb),
      sex: latestMetrics.sex ?? undefined,
      age: latestMetrics.age ?? undefined,
      dietType: latestMetrics.diet_type,
      allergies: ["None","None","None"],
      preferredProtein: latestMetrics.preferred_protein,
      avoidFood: latestMetrics.avoid_food,
    };
    const a = (latestMetrics.allergies ?? []) as string[];
    inputs.allergies = [a[0] ?? "None", a[1] ?? "None", a[2] ?? "None"];

    const week = generateWeekPlan(inputs);

    const o:any = {
      calories: override.calories ? Number(override.calories) : undefined,
      protein_g: override.protein_g ? Number(override.protein_g) : undefined,
      carbs_g: override.carbs_g ? Number(override.carbs_g) : undefined,
      fats_g: override.fats_g ? Number(override.fats_g) : undefined,
    };
    const newTargets = applyMacroOverride(week.targets, o, inputs.mealsPerDay);
    const payload = { kind:"week", inputs, targets: newTargets, week: week.week, grocery: week.grocery, restrictions: week.meta.restrictions, override: o };

    const { error } = await supabase.from("meal_plans").insert({
      user_id: clientId,
      metrics_id: latestMetrics.id,
      calories: newTargets.calories,
      protein_g: newTargets.protein_g,
      carbs_g: newTargets.carbs_g,
      fats_g: newTargets.fats_g,
      plan_json: payload
    });

    if(error) setStatus(error.message);
    else { setStatus("Regenerated + saved new plan for client."); await load(); }
  }

  if(!allowed){
    return (
      <div className="card">
        <h2 style={{marginTop:0}}>Admin</h2>
        <p className="small">Admin access required.</p>
      </div>
    );
  }

  return (
    <div className="grid">
      <div className="card">
        <h2 style={{marginTop:0}}>Client</h2>
        <div className="small">Name: {client?.full_name ?? clientId}</div>
        <div className="small">Joined: {client ? new Date(client.created_at).toLocaleString() : "-"}</div>

        <div className="hr" />

        <h3 style={{margin:"0 0 6px 0"}}>Macro tweak → regenerate plan</h3>
        <p className="small" style={{marginTop:0}}>Leave blank to keep current macros.</p>

        <div className="row" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div className="row" style={{margin:0}}>
            <label>Calories</label>
            <input value={override.calories} onChange={(e)=>setOverride(o=>({...o, calories:e.target.value}))} placeholder="e.g., 2400" />
          </div>
          <div className="row" style={{margin:0}}>
            <label>Protein (g)</label>
            <input value={override.protein_g} onChange={(e)=>setOverride(o=>({...o, protein_g:e.target.value}))} placeholder="e.g., 190" />
          </div>
          <div className="row" style={{margin:0}}>
            <label>Carbs (g)</label>
            <input value={override.carbs_g} onChange={(e)=>setOverride(o=>({...o, carbs_g:e.target.value}))} placeholder="e.g., 250" />
          </div>
          <div className="row" style={{margin:0}}>
            <label>Fats (g)</label>
            <input value={override.fats_g} onChange={(e)=>setOverride(o=>({...o, fats_g:e.target.value}))} placeholder="e.g., 70" />
          </div>
        </div>

        <button className="btn" onClick={regenerateWithOverride}>Regenerate & Save Plan</button>

        <div className="hr" />

        <h3 style={{margin:"0 0 6px 0"}}>Trainer notes</h3>
        <textarea rows={3} value={note} onChange={(e)=>setNote(e.target.value)} placeholder="Client feedback, adjustments, reminders..." />
        <button className="btn secondary" style={{marginTop:10}} onClick={addNote}>Save note</button>

        {status && <div className="small" style={{marginTop:10}}>{status}</div>}
      </div>

      <div className="card">
        <h2 style={{marginTop:0}}>Recent Plans</h2>
        {!plans.length ? <p className="small">No plans yet.</p> : (
          <table>
            <thead><tr><th>Date</th><th>Cal</th><th>P</th><th>C</th><th>F</th></tr></thead>
            <tbody>
              {plans.map(p=>(
                <tr key={p.id}>
                  <td>{new Date(p.created_at).toLocaleString()}</td>
                  <td>{p.calories}</td><td>{p.protein_g} g</td><td>{p.carbs_g} g</td><td>{p.fats_g} g</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="hr" />

        <div className="hr" />

<h2 style={{marginTop:0}}>Messages</h2>
{!messages.length ? <p className="small">No messages yet.</p> : (
  <div style={{display:"grid", gap:10}}>
    {messages.map((m:any)=>(
      <div key={m.id} className="card" style={{padding:12, background:"#0f131b"}}>
        <div className="small"><b>{m.sender_role==="admin" ? "Coach" : "Client"}</b> • {new Date(m.created_at).toLocaleString()}</div>
        <div style={{marginTop:6}}>{m.body}</div>
      </div>
    ))}
  </div>
)}

<div className="row" style={{marginTop:12}}>
  <label>Reply as coach</label>
  <textarea rows={3} value={reply} onChange={(e)=>setReply(e.target.value)} placeholder="Type a reply..." />
  <button className="btn secondary" style={{marginTop:10}} onClick={sendReply}>Send reply</button>
</div>

<h2 style={{marginTop:0}}>Recent Check-ins</h2>
        {!checkins.length ? <p className="small">No check-ins yet.</p> : (
          <table>
            <thead><tr><th>Date</th><th>Weight</th><th>Notes</th></tr></thead>
            <tbody>
              {checkins.map((c,idx)=>(
                <tr key={idx}>
                  <td>{c.checkin_date}</td>
                  <td>{c.weight_lb ?? "-"}</td>
                  <td>{c.notes ?? "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
