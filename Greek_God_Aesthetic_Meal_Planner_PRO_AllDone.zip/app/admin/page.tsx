import Topbar from "../_components/Topbar";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function AdminPage(){
  const supabase = createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  if(!user){
    return (
      <>
        {/* @ts-expect-error Async Server Component */}
        <Topbar />
        <div className="card"><h2 style={{marginTop:0}}>Admin</h2><p className="small">Please log in.</p><Link className="btn" href="/login">Login</Link></div>
      </>
    );
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single();
  if(profile?.role !== "admin"){
    return (
      <>
        {/* @ts-expect-error Async Server Component */}
        <Topbar />
        <div className="card">
          <h2 style={{marginTop:0}}>Admin</h2>
          <p className="small">Not an admin yet. In Supabase table <code>profiles</code>, set your <code>role</code> to <code>admin</code>.</p>
        </div>
      </>
    );
  }

  const { data: clients } = await supabase.from("profiles").select("id, full_name, created_at, role").order("created_at",{ascending:false}).limit(200);

  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <div className="card">
        <h2 style={{marginTop:0}}>Admin Dashboard</h2>
        <table>
          <thead><tr><th>Name</th><th>Role</th><th>Created</th><th></th></tr></thead>
          <tbody>
            {clients?.map(c=>(
              <tr key={c.id}>
                <td>{c.full_name ?? c.id}</td>
                <td>{c.role}</td>
                <td>{new Date(c.created_at).toLocaleString()}</td>
                <td><Link href={`/admin/client/${c.id}`}>Open</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
