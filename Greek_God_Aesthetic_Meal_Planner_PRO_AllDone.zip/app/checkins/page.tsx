import Topbar from "../_components/Topbar";
import Checkins from "./ui";

export default function CheckinsPage(){
  return (
    <>
      {/* @ts-expect-error Async Server Component */}
      <Topbar />
      <Checkins />
    </>
  );
}
