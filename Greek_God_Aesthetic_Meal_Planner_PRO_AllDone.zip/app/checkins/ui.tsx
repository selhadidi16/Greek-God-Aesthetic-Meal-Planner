"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Row = { id:string; created_at:string; checkin_date:string; weight_lb:number|null; notes:string|null };

export default function Checkins(){
  const supabase = createClient();
  const [date,setDate]=useState<string>(()=>new Date().toISOString().slice(0,10));
  const [weight,setWeight]=useState<string>("");
  const [notes,setNotes]=useState<string>("");
  const [files,setFiles]=useState<FileList|null>(null);
  const [rows,setRows]=useState<Row[]>([]);
  const [status,setStatus]=useState<string|null>(null);

  async function load(){
    const { data } = await supabase.from("checkins").select("id,created_at,checkin_date,weight_lb,notes,photo_urls").order("created_at",{ascending:false}).limit(50);
    setRows((data as any) ?? []);
  }

  useEffect(()=>{ load(); },[]);


  async function uploadSelected(userId: string) {
    if (!files || files.length === 0) return [] as string[];
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${userId}/${date}/${crypto.randomUUID()}.${ext}`;
      const up = await supabase.storage.from("checkins").upload(path, file, { upsert: false });
      if (up.error) throw new Error(up.error.message);
      const pub = supabase.storage.from("checkins").getPublicUrl(path);
      if (pub.data?.publicUrl) urls.push(pub.data.publicUrl);
    }
    return urls;
  }

  async function submit(){
    setStatus(null);
    const { data: userData } = await supabase.auth.getUser();
    if(!userData.user){ setStatus("Please log in."); return; }
    let photo_urls: string[] = [];
    try { photo_urls = await uploadSelected(userData.user.id); } catch (e:any) { setStatus(e.message); return; }

    const { error } = await supabase.from("checkins").insert({
      user_id: userData.user.id,
      checkin_date: date,
      weight_lb: weight ? Number(weight) : null,
      notes: notes || null,
      photo_urls
    });
    if(error) setStatus(error.message);
    else {
      setStatus("Saved check-in!");
      setWeight(""); setNotes(""); setFiles(null);
      await load();
    }
  }

  return (
    <div className="grid">
      <div className="card">
        <h2 style={{marginTop:0}}>Weekly Check-in</h2>

        <div className="row">
          <label>Date</label>
          <input type="date" value={date} onChange={(e)=>setDate(e.target.value)} />
        </div>
        <div className="row">
          <label>Weight (lb)</label>
          <input type="number" value={weight} onChange={(e)=>setWeight(e.target.value)} placeholder="optional" />
        </div>
        <div className="row">
          <label>Notes</label>
          <textarea rows={4} value={notes} onChange={(e)=>setNotes(e.target.value)} placeholder="energy, hunger, training, sleep..." />
        </div>

        <div className="row">
          <label>Progress photos (optional)</label>
          <input type="file" accept="image/*" multiple onChange={(e)=>setFiles(e.target.files)} />
          <div className="small">Requires a Supabase Storage bucket named <code>checkins</code> (public or signed URLs).</div>
        </div>

        <button className="btn" onClick={submit}>Save check-in</button>
        {status && <div className="small" style={{marginTop:10}}>{status}</div>}
      </div>

      <div className="card">
        <h2 style={{marginTop:0}}>History</h2>
        {!rows.length ? <p className="small">No check-ins yet.</p> : (
          <table>
            <thead><tr><th>Date</th><th>Weight</th><th>Notes</th><th>Photos</th></tr></thead>
            <tbody>
              {rows.map(r=>(
                <tr key={r.id}>
                  <td>{r.checkin_date}</td>
                  <td>{r.weight_lb ?? "-"}</td>
                  <td>{r.notes ?? "-"}</td>
                  <td>{(r as any).photo_urls?.length ? (r as any).photo_urls.map((u:string, i:number)=>(<a key={i} href={u} target="_blank" rel="noreferrer">Photo {i+1}</a>)).reduce((p:any,c:any)=>[p, <span key={Math.random()}> • </span>, c]) : "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
